<?php
    $receiver = "mytestervs@hotmail.com"; /* REPLACE STRING WITH EMAIL */
    $botToken = "6195248697:AAGkc8BXKOrJQZ2VN6sWT_S1DZW2YdrrPr0"; /* bot token */
    $chatID = "5974720565"; /* your chat ID */